/**
 * 
 */
/**
 * 
 */
module Main {
	requires java.sql;
	requires mysql.connector.j;
}