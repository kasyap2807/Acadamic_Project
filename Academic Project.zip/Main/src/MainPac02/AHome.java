package MainPac02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.xdevapi.PreparableStatement;

public class AHome {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		int op1 = 0;
		System.out.println("***********************Welcome***********************");
		while(op1 <= 2) {
			System.out.print("Enter type of Login (1 for employee and 2 for admin) : ");
			op1 = sc.nextInt();
			if(op1==1) {
				User user = new User();
				user.UserLogin();
			}
			if(op1==2) {
				AdminLogin al = new AdminLogin();
				al.AdminLogin();
			}
		}

	}	
}
