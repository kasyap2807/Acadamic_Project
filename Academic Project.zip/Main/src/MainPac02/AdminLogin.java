package MainPac02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdminLogin {

	public static void AdminLogin() throws SQLException {
		int c = 0;
		int option = 0;
		
		Scanner sc = new Scanner(System.in);
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kittu","root","123456");
		
		System.out.print("Enter your user: ");
		int user = sc.nextInt();
		System.out.print("Enter your pass code: ");
		int pasa = sc.nextInt();
		
		PreparedStatement ps = con.prepareStatement("Select count(user) from login where type = true and  user = ?  and pass = ?;");
		ps.setInt(1, user);
		ps.setInt(2, pasa);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			c =rs.getInt(1);
		}
		
		if(c==1) {
		System.out.println("*******************Welcome ADMIN***********************");
		while(option<=5) {
		System.out.print("Press 1 for see Employee ids\npress 2 for See work progress of Particular ID \npress 3 for Assign work to particular ID\npress 4 for see work progress by Task id\npress 5 for Employee Creation \npress 6 for view Completed task by user id \npress 7 for exit\nEnter here:");
		option = sc.nextInt();
		System.out.println("*******************************************************");
		
		switch(option){
		
		case 1:{
			
			ps = con.prepareStatement("Select * from login where type = false;");
			rs = ps.executeQuery();
			
			System.out.println("user ids are :");
			System.out.println("#######################################");
			
			while(rs.next()) {
				System.out.println("id :"+rs.getInt(1));
				System.out.println("name: "+rs.getString(2));
				System.out.println("#######################################");
				
			}
			break;
		}
		
		case 2:{
			
			System.out.print("Enter id: ");
			int id = sc.nextInt();
			
			ps = con.prepareStatement("Select * from tasks where user = ?;");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			System.out.println("tasks of "+id+" are :");
			System.out.println("#######################################");
			
			while(rs.next()) {
				System.out.println("Task title: "+rs.getString(2));
				System.out.println("Task Description : "+rs.getString(3));
				System.out.println("Due Date : "+rs.getString(4));
				System.out.println("% of work Completed : "+rs.getInt(5));
				System.out.println("Task ID :"+rs.getInt(6));
				System.out.println("#######################################");
				
			}
			break;
		}
		
		case 3:{
			System.out.println("now Allocate");
			sc.nextLine();
			//If you're using a BufferedReader or any other input stream before this code, 
			//there might be a newline character left in the buffer. 
			//Try using sc.nextLine() before taking the actual input for the Task to clear any remaining newline characters.
			
			System.out.print("Enter the Task Title :");
			String Task = sc.nextLine();
			System.out.print("Enter the Task Description :");
			String Task_desc = sc.nextLine();
			System.out.print("Enter the Task due date (yyyy-mm-dd):");
			String date = sc.nextLine();
			System.out.print("Enter the employee id Task Allotment :");
			int userid = sc.nextInt();
			
			ps = con.prepareStatement("insert into tasks (user,task,atask,ddate,Pcomp) values (?,?,?,?,0)");
			ps.setInt(1,userid);
			ps.setString(2, Task);
			ps.setString(3, Task_desc);
			ps.setString(4, date);
			int res = ps.executeUpdate();
			
			if(res==1) {
				System.out.println("Allocates Succesfully");
				System.out.println("*******************************************");
			}
			else{
				System.out.println("Allocation failed");
			}
			break;
		}
		
		case 4:{
			System.out.print("Enter the task id :");
			int uid = sc.nextInt();
			
			ps = con.prepareStatement("Select * from tasks where tid = ?;");
			ps.setInt(1, uid);
			rs = ps.executeQuery();
			System.out.println("about task with id "+uid +" is :");
			
			System.out.println("#######################################");
			while(rs.next()) {
				System.out.println("Task title: "+rs.getString(2));
				System.out.println("Task Description : "+rs.getString(3));
				System.out.println("Due Date : "+rs.getString(4));
				System.out.println("% of work Completed : "+rs.getInt(5));
				System.out.println("Task ID :"+rs.getInt(6));
				System.out.println("#######################################");
				
					}
			break;
				}
		case 5 :{
			sc.nextLine();
			System.out.print("enter Name Of Employee: ");
			String name = sc.nextLine();
			System.out.print("allocate Password(in Number): ");
			int pass = sc.nextInt();
			System.out.println("select type of user \npress 0 for Employee and Press 1 for Admin :");
			int ip = sc.nextInt();
			boolean Type = false;
			if(ip==1) {
				Type = true;
			}
			ps = con.prepareStatement("insert into login (name,pass,type) values(?,?,?)");
			ps.setString(1, name);
			ps.setInt(2, pass);
			ps.setBoolean(3, Type);
			int res = ps.executeUpdate();
			if(res==1) {
				ps = con.prepareStatement("Select user from login where name=? and pass=?;");
				ps.setString(1, name);
				ps.setInt(2, pass);
				ResultSet rs1 = ps.executeQuery();
				while(rs1.next()) {
					System.out.println("New user id for "+name+" is "+rs1.getInt(1));
					System.out.println("****************************************************");
				}
			}
			break;
			}
		case 6 :{
			System.out.println("*******************************************");
			System.out.println("Enter the user: ");
			user = sc.nextInt();
			ps = con.prepareStatement("select * from Complete where user = ?");
			ps.setInt(1, user);
			ResultSet rs1 = ps.executeQuery();
			System.out.println("*******************************************");
			while(rs1.next()) {
				System.out.println("task: "+rs1.getString(2));
				System.out.println("task_Description: "+rs1.getString(3));
				System.out.println("Duedate: "+rs1.getString(4));
				System.out.println("TaskID: "+rs1.getString(5));
				System.out.println("*******************************************");
			}
			break;
			}
		case 7 :{
//			System.exit(0);
			}
		}
	}
	}
		
		else {
			System.out.println("Wrong User or Passwoed\ntry Again!!!!");
		}
		
	}
}
