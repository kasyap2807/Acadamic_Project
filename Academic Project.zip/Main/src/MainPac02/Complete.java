package MainPac02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Complete {

	public static void Complete() throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kittu","root","123456");
		PreparedStatement ps = con.prepareStatement("Select * from tasks where Pcomp = 100;");
		ResultSet rs = ps.executeQuery();		
		while(rs.next()) {
			ps = con.prepareStatement("insert into Complete values(?,?,?,?,?);");
			ps.setInt(1,rs.getInt(1));
			ps.setString(2,rs.getString(2));
			ps.setString(3,rs.getString(3));
			ps.setString(4,rs.getString(4));
			ps.setInt(5,rs.getInt(6));
			ps.executeUpdate();
			}
		ps = con.prepareStatement("delete from tasks where Pcomp = 100;");
		ps.executeUpdate();
	}
}
