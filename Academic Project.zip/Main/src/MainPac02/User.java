package MainPac02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class User {

	public static void UserLogin() throws SQLException {
		int c = 0 ;
		Scanner sc = new Scanner(System.in);
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kittu","root","123456");
		System.out.print("Enter your user: ");
		int user = sc.nextInt();
		System.out.print("Enter your pass code: ");
		int pasa = sc.nextInt();
		PreparedStatement ps = con.prepareStatement("Select count(user) from login where type = false and  user = ?  and pass = ?;");
		ps.setInt(1, user);
		ps.setInt(2, pasa);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			c =rs.getInt(1);
		}
		if(c==1) {
			ps = con.prepareStatement("select * from tasks where user = ?;");
			ps.setInt(1, user);
			rs = ps.executeQuery();
			System.out.println("********************************************");
			while(rs.next()) {
				System.out.println("Task title: "+rs.getString(2));
				System.out.println("Task Description : "+rs.getString(3));
				System.out.println("Due Date : "+rs.getString(4));
				System.out.println("% of work Completed : "+rs.getInt(5));
				System.out.println("Task ID :"+rs.getInt(6));
				ps = con.prepareStatement("SELECT DATEDIFF(?,CURDATE()); ");
				ps.setString(1,rs.getString(4));
				ResultSet rs2 = ps.executeQuery();
				while(rs2.next()) {
					System.out.println("Days left: "+rs2.getInt(1));
				}
				System.out.println("********************************************");
			}
			int option = 0;
			while(option!=3) {
			System.out.print("For Update task Status Press 1 ,FOR view Completed Tasks PRESS 2 For Exit Press 3: ");
			option = sc.nextInt();
			if(option==1) {
				System.out.print("Enter Task id : ");
				int tid = sc.nextInt();
				System.out.print("Enter % of Work Done (0-100%): ");
				int pdone = sc.nextInt();
				ps = con.prepareStatement("update tasks set Pcomp = ? where tid = ? and user = ?;");
				ps.setInt(1, pdone);
				ps.setInt(2, tid);
				ps.setInt(3, user);
				int res = ps.executeUpdate();
				Complete comp = new Complete();
				comp.Complete();
				System.out.println((res>=1)?"Success":"failed"+"\nsuccesfully logged out"+"\n*************************");		
			}
			if(option==2) {
				ps = con.prepareStatement("select * from Complete where user = ?");
				ps.setInt(1, user);
				ResultSet rs1 = ps.executeQuery();
				System.out.println("*******************************************");
				while(rs1.next()) {
					System.out.println("task: "+rs1.getString(2));
					System.out.println("task_Description: "+rs1.getString(3));
					System.out.println("Duedate: "+rs1.getString(4));
					System.out.println("TaskID: "+rs1.getString(5));
					System.out.println("*******************************************");
				}
			}	
			}
		}
		else {
			System.out.println("wrong user or password \ntry Again!!!!");
		}
		
	}
}
